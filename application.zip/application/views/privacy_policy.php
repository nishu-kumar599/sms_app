<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="SMS Application">
  <meta name="author" content="Łukasz Holeczek">
  <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,jQuery,CSS,HTML,RWD,Dashboard,Vue,Vue.js,React,React.js">
  <link rel="shortcut icon" href="<?php echo base_url(); ?>img/favicon.png">
  <title> SMS APP</title>







  <!-- Icons -->



  <link href="<?php echo base_url(); ?>vendors/css/font-awesome.min.css" rel="stylesheet">



  <link href="<?php echo base_url(); ?>vendors/css/simple-line-icons.min.css" rel="stylesheet">



  <link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet">







  <!-- Styles required by this views -->



  <link href="<?php echo base_url(); ?>vendors/css/daterangepicker.min.css" rel="stylesheet">



  <link href="<?php echo base_url(); ?>vendors/css/gauge.min.css" rel="stylesheet">



  <link href="<?php echo base_url(); ?>vendors/css/toastr.min.css" rel="stylesheet">

  <link href="<?php echo base_url(); ?>vendors/css/dataTables.bootstrap4.min.css" rel="stylesheet">

   <link href="<?php echo base_url(); ?>css/custom-style.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>lib/css/nanoscroller.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>lib/css/emoji.css" rel="stylesheet">
<style type="text/css">
  .avatar-img-margin {
    margin-right: 80px !important;
}
.right a {
      margin-left: 940px;
}

	.app-footer {

    margin: 0px !important;

}

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
      $( document ).ready(function() {
setTimeout(function() { $("#toast-container").hide(); }, 4000);
 });
</script>
</head>
<style>

.btn-primary{background-color:#1843d7;}
</style>
<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
  <header class="app-header navbar">
    <button class="navbar-toggler mobile-sidebar-toggler d-lg-none" type="button">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="#"> <!--img src="img/" style=""--> </a>
    

</header>
  <div id="toast-container" class="toast-top-right">
 
</div>

    <div class="app-body">
    <!-- Main content -->
    <main class="main" style="margin: 0;margin-top: 50px;">

  
       <div class="container-fluid">
        <div class="animated fadeIn"> 
          <div class="row">
            <div class="col-lg-3"> </div>
            <div class="col-lg-12">
              <div class="card">
                <div class="card-header">
                  <i class="fa fa-envelope"></i>Privacy Policy 
                  
                </div>
                <div class="card-body col-lg-12" align="left">
                 
                      <label class="col-form-label" for="prependedInput">  					
					</label>
                    
                    </div>

                </div>
              </div>
            </div>
			            <div class="col-lg-3"> </div>

            <!--/.col-->
          </div>
          
          <!--/.row-->
        </div>

      </div>
      <!-- /.conainer-fluid -->
    </main>
 </div>


<?php include_once('footer.php')  ?>
